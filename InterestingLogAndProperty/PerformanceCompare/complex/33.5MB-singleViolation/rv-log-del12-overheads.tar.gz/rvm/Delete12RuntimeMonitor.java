package rvm;
import java.util.concurrent.*;
import java.util.concurrent.locks.*;
import java.util.*;
import java.lang.ref.*;
import com.runtimeverification.rvmonitor.java.rt.*;
import com.runtimeverification.rvmonitor.java.rt.ref.*;
import com.runtimeverification.rvmonitor.java.rt.table.*;
import com.runtimeverification.rvmonitor.java.rt.tablebase.AbstractIndexingTree;
import com.runtimeverification.rvmonitor.java.rt.tablebase.SetEventDelegator;
import com.runtimeverification.rvmonitor.java.rt.tablebase.TableAdopter.Tuple2;
import com.runtimeverification.rvmonitor.java.rt.tablebase.TableAdopter.Tuple3;
import com.runtimeverification.rvmonitor.java.rt.tablebase.IDisableHolder;
import com.runtimeverification.rvmonitor.java.rt.tablebase.IMonitor;
import com.runtimeverification.rvmonitor.java.rt.tablebase.DisableHolder;
import com.runtimeverification.rvmonitor.java.rt.tablebase.TerminatedMonitorCleaner;
import java.util.concurrent.atomic.AtomicInteger;

final class Delete12Monitor_Set extends com.runtimeverification.rvmonitor.java.rt.tablebase.AbstractMonitorSet<Delete12Monitor> {

	Delete12Monitor_Set(){
		this.size = 0;
		this.elements = new Delete12Monitor[4];
	}
	final void event_delete(String user, String db, String p, String data, long time) {
		int numAlive = 0 ;
		for(int i = 0; i < this.size; i++){
			Delete12Monitor monitor = this.elements[i];
			if(!monitor.isTerminated()){
				elements[numAlive] = monitor;
				numAlive++;

				final Delete12Monitor monitorfinalMonitor = monitor;
				monitor.Prop_1_event_delete(user, db, p, data, time);
				if(monitorfinalMonitor.Prop_1_Category_fail) {
					monitorfinalMonitor.Prop_1_handler_fail();
				}
			}
		}
		for(int i = numAlive; i < this.size; i++){
			this.elements[i] = null;
		}
		size = numAlive;
	}
	final void event_insert(String user, String db, String p, String data, long time) {
		int numAlive = 0 ;
		for(int i = 0; i < this.size; i++){
			Delete12Monitor monitor = this.elements[i];
			if(!monitor.isTerminated()){
				elements[numAlive] = monitor;
				numAlive++;

				final Delete12Monitor monitorfinalMonitor = monitor;
				monitor.Prop_1_event_insert(user, db, p, data, time);
				if(monitorfinalMonitor.Prop_1_Category_fail) {
					monitorfinalMonitor.Prop_1_handler_fail();
				}
			}
		}
		for(int i = numAlive; i < this.size; i++){
			this.elements[i] = null;
		}
		size = numAlive;
	}
	final void event_select(String user, String b, String c, String d, long time) {
		int numAlive = 0 ;
		for(int i = 0; i < this.size; i++){
			Delete12Monitor monitor = this.elements[i];
			if(!monitor.isTerminated()){
				elements[numAlive] = monitor;
				numAlive++;

				final Delete12Monitor monitorfinalMonitor = monitor;
				monitor.Prop_1_event_select(user, b, c, d, time);
				if(monitorfinalMonitor.Prop_1_Category_fail) {
					monitorfinalMonitor.Prop_1_handler_fail();
				}
			}
		}
		for(int i = numAlive; i < this.size; i++){
			this.elements[i] = null;
		}
		size = numAlive;
	}
	final void event_update(String user, String b, String c, String d, long time) {
		int numAlive = 0 ;
		for(int i = 0; i < this.size; i++){
			Delete12Monitor monitor = this.elements[i];
			if(!monitor.isTerminated()){
				elements[numAlive] = monitor;
				numAlive++;

				final Delete12Monitor monitorfinalMonitor = monitor;
				monitor.Prop_1_event_update(user, b, c, d, time);
				if(monitorfinalMonitor.Prop_1_Category_fail) {
					monitorfinalMonitor.Prop_1_handler_fail();
				}
			}
		}
		for(int i = numAlive; i < this.size; i++){
			this.elements[i] = null;
		}
		size = numAlive;
	}
	final void event_script_start(String user, long time) {
		int numAlive = 0 ;
		for(int i = 0; i < this.size; i++){
			Delete12Monitor monitor = this.elements[i];
			if(!monitor.isTerminated()){
				elements[numAlive] = monitor;
				numAlive++;

				final Delete12Monitor monitorfinalMonitor = monitor;
				monitor.Prop_1_event_script_start(user, time);
				if(monitorfinalMonitor.Prop_1_Category_fail) {
					monitorfinalMonitor.Prop_1_handler_fail();
				}
			}
		}
		for(int i = numAlive; i < this.size; i++){
			this.elements[i] = null;
		}
		size = numAlive;
	}
	final void event_script_end(String user, long time) {
		int numAlive = 0 ;
		for(int i = 0; i < this.size; i++){
			Delete12Monitor monitor = this.elements[i];
			if(!monitor.isTerminated()){
				elements[numAlive] = monitor;
				numAlive++;

				final Delete12Monitor monitorfinalMonitor = monitor;
				monitor.Prop_1_event_script_end(user, time);
				if(monitorfinalMonitor.Prop_1_Category_fail) {
					monitorfinalMonitor.Prop_1_handler_fail();
				}
			}
		}
		for(int i = numAlive; i < this.size; i++){
			this.elements[i] = null;
		}
		size = numAlive;
	}
	final void event_script_svn(String user, String b, String c, int d, int e, long time) {
		int numAlive = 0 ;
		for(int i = 0; i < this.size; i++){
			Delete12Monitor monitor = this.elements[i];
			if(!monitor.isTerminated()){
				elements[numAlive] = monitor;
				numAlive++;

				final Delete12Monitor monitorfinalMonitor = monitor;
				monitor.Prop_1_event_script_svn(user, b, c, d, e, time);
				if(monitorfinalMonitor.Prop_1_Category_fail) {
					monitorfinalMonitor.Prop_1_handler_fail();
				}
			}
		}
		for(int i = numAlive; i < this.size; i++){
			this.elements[i] = null;
		}
		size = numAlive;
	}
	final void event_script_md5(String user, String b, long time) {
		int numAlive = 0 ;
		for(int i = 0; i < this.size; i++){
			Delete12Monitor monitor = this.elements[i];
			if(!monitor.isTerminated()){
				elements[numAlive] = monitor;
				numAlive++;

				final Delete12Monitor monitorfinalMonitor = monitor;
				monitor.Prop_1_event_script_md5(user, b, time);
				if(monitorfinalMonitor.Prop_1_Category_fail) {
					monitorfinalMonitor.Prop_1_handler_fail();
				}
			}
		}
		for(int i = numAlive; i < this.size; i++){
			this.elements[i] = null;
		}
		size = numAlive;
	}
	final void event_commit(String user, int b, long time) {
		int numAlive = 0 ;
		for(int i = 0; i < this.size; i++){
			Delete12Monitor monitor = this.elements[i];
			if(!monitor.isTerminated()){
				elements[numAlive] = monitor;
				numAlive++;

				final Delete12Monitor monitorfinalMonitor = monitor;
				monitor.Prop_1_event_commit(user, b, time);
				if(monitorfinalMonitor.Prop_1_Category_fail) {
					monitorfinalMonitor.Prop_1_handler_fail();
				}
			}
		}
		for(int i = numAlive; i < this.size; i++){
			this.elements[i] = null;
		}
		size = numAlive;
	}
}

class Delete12Monitor extends com.runtimeverification.rvmonitor.java.rt.tablebase.AbstractAtomicMonitor implements Cloneable, com.runtimeverification.rvmonitor.java.rt.RVMObject {
	protected Object clone() {
		try {
			Delete12Monitor ret = (Delete12Monitor) super.clone();
			return ret;
		}
		catch (CloneNotSupportedException e) {
			throw new InternalError(e.toString());
		}
	}

	/**
	* This data structure represents a record that describes which user deletes what data at what time.
	**/
	public static class DeleteRecord {
		public final long ts;
		public final String user;
		public final String deleteData;

		public DeleteRecord(long ts, String user, String deleteData) {
			this.ts = ts;
			this.user = user;
			this.deleteData = deleteData;
		}

		public boolean equals(DeleteRecord other) {
			if (other == null)
			return false;
			if (this.ts != other.ts)
			return false;

			return (this.user.equals(other.user) &&
			this.deleteData.equals(other.deleteData));
		}

		public String print() {
			return "@" + ts + " delete (" + user + ", db1, " + deleteData + ")\n";
		}
	}

	private static Set<DeleteRecord> suspiciousRecords = new HashSet<>();
	private static HashMap<Long, Set<String>> cond2HasHopeDataList = new HashMap<>();
	private static Set<String> db1InsertedData = new HashSet<>();
	private static Set<String> db2InsertedData = new HashSet<>();

	private void removeValidatedRecords(String data) {
		List<DeleteRecord> removedRecords = new ArrayList<>();
		for (DeleteRecord deleteRecord : suspiciousRecords) {
			if (deleteRecord.deleteData.equals(data)) {
				removedRecords.add(deleteRecord);
			}
		}
		suspiciousRecords.removeAll(removedRecords);
	}

	public static void printAllViolations() {
		for (DeleteRecord suspiciousRecord : suspiciousRecords) {
			if (db2InsertedData.contains(suspiciousRecord.deleteData)) {
				System.out.println("Violation: " + suspiciousRecord.print());
			} else {
				Set<String> hopefulDataList = cond2HasHopeDataList.get(suspiciousRecord.ts);
				if (hopefulDataList == null)
				System.out.println("Violation: " + suspiciousRecord.print());

				else if (hopefulDataList.contains(suspiciousRecord.deleteData)) {
					System.out.println("Satisfy the second condition of the disjunctive formula");
				} else {
					System.out.println("Violation: " + suspiciousRecord.print());
				}
			}
		}

if(suspiciousRecords.size() > 0)
System.exit(0);
	}

	static final int Prop_1_transition_delete[] = {0, 1};;
	static final int Prop_1_transition_insert[] = {0, 1};;
	static final int Prop_1_transition_select[] = {0, 1};;
	static final int Prop_1_transition_update[] = {0, 1};;
	static final int Prop_1_transition_script_start[] = {0, 1};;
	static final int Prop_1_transition_script_end[] = {0, 1};;
	static final int Prop_1_transition_script_svn[] = {0, 1};;
	static final int Prop_1_transition_script_md5[] = {0, 1};;
	static final int Prop_1_transition_commit[] = {0, 1};;

	volatile boolean Prop_1_Category_fail = false;

	private final AtomicInteger pairValue;

	Delete12Monitor() {
		this.pairValue = new AtomicInteger(this.calculatePairValue(-1, 0) ) ;

	}

	@Override public final int getState() {
		return this.getState(this.pairValue.get() ) ;
	}
	@Override public final int getLastEvent() {
		return this.getLastEvent(this.pairValue.get() ) ;
	}
	private final int getState(int pairValue) {
		return (pairValue & 1) ;
	}
	private final int getLastEvent(int pairValue) {
		return (pairValue >> 1) ;
	}
	private final int calculatePairValue(int lastEvent, int state) {
		return (((lastEvent + 1) << 1) | state) ;
	}

	private final int handleEvent(int eventId, int[] table) {
		int nextstate;
		while (true) {
			int oldpairvalue = this.pairValue.get() ;
			int oldstate = this.getState(oldpairvalue) ;
			nextstate = table [ oldstate ];
			int nextpairvalue = this.calculatePairValue(eventId, nextstate) ;
			if (this.pairValue.compareAndSet(oldpairvalue, nextpairvalue) ) {
				break;
			}
		}
		return nextstate;
	}

	final boolean Prop_1_event_delete(String user, String db, String p, String data, long time) {
		{
			if (data.equals("unknown"))
			return true;

			if (db.equals("db1")) {
				this.suspiciousRecords.add(new DeleteRecord(LogEntryExtractor.TimeStamp, user, data));

				if (db2InsertedData.contains(data))
				return true;

				else {
					if (db1InsertedData.contains(data)) {
						Set<String> dataList = this.cond2HasHopeDataList.get(LogEntryExtractor.TimeStamp);
						if (dataList == null) {
							dataList = new HashSet<>();
							this.cond2HasHopeDataList.put(LogEntryExtractor.TimeStamp, dataList);
						}

						dataList.add(data);
					}
				}
			} else if (db.equals("db2")) {
				this.removeValidatedRecords(data);
			}

		}

		int nextstate = this.handleEvent(0, Prop_1_transition_delete) ;
		this.Prop_1_Category_fail = nextstate == 1;

		return true;
	}

	final boolean Prop_1_event_insert(String user, String db, String p, String data, long time) {
		{
			if (data.equals("unknown"))
			return false;

			if (db.equals("db1")) {
				this.db1InsertedData.add(data);
			} else if (db.equals("db2")) {
				this.db2InsertedData.add(data);
			}
		}

		int nextstate = this.handleEvent(1, Prop_1_transition_insert) ;
		this.Prop_1_Category_fail = nextstate == 1;

		return true;
	}

	final boolean Prop_1_event_select(String user, String b, String c, String d, long time) {
		{       }

		int nextstate = this.handleEvent(2, Prop_1_transition_select) ;
		this.Prop_1_Category_fail = nextstate == 1;

		return true;
	}

	final boolean Prop_1_event_update(String user, String b, String c, String d, long time) {
		{        }

		int nextstate = this.handleEvent(3, Prop_1_transition_update) ;
		this.Prop_1_Category_fail = nextstate == 1;

		return true;
	}

	final boolean Prop_1_event_script_start(String user, long time) {
		{      }

		int nextstate = this.handleEvent(4, Prop_1_transition_script_start) ;
		this.Prop_1_Category_fail = nextstate == 1;

		return true;
	}

	final boolean Prop_1_event_script_end(String user, long time) {
		{       }

		int nextstate = this.handleEvent(5, Prop_1_transition_script_end) ;
		this.Prop_1_Category_fail = nextstate == 1;

		return true;
	}

	final boolean Prop_1_event_script_svn(String user, String b, String c, int d, int e, long time) {
		{        }

		int nextstate = this.handleEvent(6, Prop_1_transition_script_svn) ;
		this.Prop_1_Category_fail = nextstate == 1;

		return true;
	}

	final boolean Prop_1_event_script_md5(String user, String b, long time) {
		{     }

		int nextstate = this.handleEvent(7, Prop_1_transition_script_md5) ;
		this.Prop_1_Category_fail = nextstate == 1;

		return true;
	}

	final boolean Prop_1_event_commit(String user, int b, long time) {
		{       }

		int nextstate = this.handleEvent(8, Prop_1_transition_commit) ;
		this.Prop_1_Category_fail = nextstate == 1;

		return true;
	}

	final void Prop_1_handler_fail (){
		{System.err.println("...");}

	}

	final void reset() {
		this.pairValue.set(this.calculatePairValue(-1, 0) ) ;

		Prop_1_Category_fail = false;
	}

	@Override
	protected final void terminateInternal(int idnum) {
		int lastEvent = this.getLastEvent();

		switch(idnum){
		}
		switch(lastEvent) {
			case -1:
			return;
			case 0:
			//delete
			return;
			case 1:
			//insert
			return;
			case 2:
			//select
			return;
			case 3:
			//update
			return;
			case 4:
			//script_start
			return;
			case 5:
			//script_end
			return;
			case 6:
			//script_svn
			return;
			case 7:
			//script_md5
			return;
			case 8:
			//commit
			return;
		}
		return;
	}

	public static int getNumberOfEvents() {
		return 9;
	}

	public static int getNumberOfStates() {
		return 2;
	}

}

public final class Delete12RuntimeMonitor implements com.runtimeverification.rvmonitor.java.rt.RVMObject {
	private static com.runtimeverification.rvmonitor.java.rt.map.RVMMapManager Delete12MapManager;
	static {
		Delete12MapManager = new com.runtimeverification.rvmonitor.java.rt.map.RVMMapManager();
		Delete12MapManager.start();
	}

	// Declarations for the Lock
	static final ReentrantLock Delete12_RVMLock = new ReentrantLock();
	static final Condition Delete12_RVMLock_cond = Delete12_RVMLock.newCondition();

	private static boolean Delete12_activated = false;

	// Declarations for Indexing Trees
	private static final Delete12Monitor Delete12__Map = new Delete12Monitor() ;

	public static int cleanUp() {
		int collected = 0;
		// indexing trees
		return collected;
	}

	static {
	}

	public static void actionsAtTheEnd(){
Delete12Monitor.printAllViolations();
	}
	// Removing terminated monitors from partitioned sets
	static {
		TerminatedMonitorCleaner.start() ;
	}
	// Setting the behavior of the runtime library according to the compile-time option
	static {
		RuntimeOption.enableFineGrainedLock(false) ;
		RuntimeOption.setIndexByVal(true) ;
	}

	public static final void deleteEvent(String user, String db, String p, String data, long time) {
		Delete12_activated = true;
		while (!Delete12_RVMLock.tryLock()) {
			Thread.yield();
		}

		Delete12Monitor matchedEntry = null;
		{
			// FindOrCreateEntry
			matchedEntry = Delete12__Map;
		}
		// D(X) main:1
		if ((matchedEntry == null) ) {
			// D(X) main:4
			Delete12Monitor created = new Delete12Monitor() ;
			matchedEntry = created;
		}
		// D(X) main:8--9
		final Delete12Monitor matchedEntryfinalMonitor = matchedEntry;
		matchedEntry.Prop_1_event_delete(user, db, p, data, time);
		if(matchedEntryfinalMonitor.Prop_1_Category_fail) {
			matchedEntryfinalMonitor.Prop_1_handler_fail();
		}

		Delete12_RVMLock.unlock();
	}

	public static final void insertEvent(String user, String db, String p, String data, long time) {
		Delete12_activated = true;
		while (!Delete12_RVMLock.tryLock()) {
			Thread.yield();
		}

		Delete12Monitor matchedEntry = null;
		{
			// FindOrCreateEntry
			matchedEntry = Delete12__Map;
		}
		// D(X) main:1
		if ((matchedEntry == null) ) {
			// D(X) main:4
			Delete12Monitor created = new Delete12Monitor() ;
			matchedEntry = created;
		}
		// D(X) main:8--9
		final Delete12Monitor matchedEntryfinalMonitor = matchedEntry;
		matchedEntry.Prop_1_event_insert(user, db, p, data, time);
		if(matchedEntryfinalMonitor.Prop_1_Category_fail) {
			matchedEntryfinalMonitor.Prop_1_handler_fail();
		}

		Delete12_RVMLock.unlock();
	}

	public static final void selectEvent(String user, String b, String c, String d, long time) {

	}

	public static final void updateEvent(String user, String b, String c, String d, long time) {

	}

	public static final void script_startEvent(String user, long time) {

	}

	public static final void script_endEvent(String user, long time) {
		
	}

	public static final void script_svnEvent(String user, String b, String c, int d, int e, long time) {

	}

	public static final void script_md5Event(String user, String b, long time) {

	}

	public static final void commitEvent(String user, int b, long time) {

	}

}
