rv-monitor rvm/ABeforeB.rvm
javac Test.java
java Test 
