pgm is benchmark1/Main.java

To execute the monitoring program,
sh bench1.sh <number of iterations> <number of violations>

e.g.
execute
sh bench1.sh 10 3

will make the main program loop 10 iterations, and 2 violations
will be inserted randomly at some iteration. 

To increase the unpredictability, one violation will be cancelled randomly.
 



