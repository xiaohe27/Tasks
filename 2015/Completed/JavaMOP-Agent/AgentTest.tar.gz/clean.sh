rm -r aj
rm -r classes
rm agent.jar
rm *.rvm
rm debug.txt
